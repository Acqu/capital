export const TimeWarpStateName = "TimeWarpState";
export const DevToolsName = "devTools";
export const InitializeJavaScriptInteropName = "InitializeJavaScriptInterop";
export const JsonRequestHandlerMethodName = "Handle";
export const ReduxDevToolsFactoryName = "ReduxDevToolsFactory";
export const ReduxDevToolsName = "reduxDevTools";
export const ReduxExtensionName = "__REDUX_DEVTOOLS_EXTENSION__";
//# sourceMappingURL=Constants.js.map